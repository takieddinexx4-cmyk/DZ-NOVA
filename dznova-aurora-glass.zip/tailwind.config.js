/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: ['class', '[data-theme="dark"]'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'Cairo', 'Tajawal', 'system-ui', 'sans-serif'],
        arabic: ['Cairo', 'Tajawal', 'Inter', 'sans-serif'],
        display: ['Space Grotesk', 'Cairo', 'Inter', 'sans-serif'],
      },
      colors: {
        aurora: {
          navy: '#060B19',
          cyan: '#22D3EE',
          blue: '#3B82F6',
          violet: '#8B5CF6',
          silver: '#E2E8F0',
        },
      },
    },
  },
  plugins: [],
};
