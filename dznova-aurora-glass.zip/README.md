# DZNOVA — AURORA GLASS

A next-generation live-streaming control center, original brand identity, and 50+ ColorOS-inspired 3D Liquid Glass SVG icon system built with React, TypeScript, Tailwind CSS, Framer Motion, and dynamically loaded React Three Fiber.

## Highlights

- **Aurora Glass Design Language**: Translucent liquid glass surfaces (`backdrop-filter` + `@supports` fallbacks, inner specular highlights, subtle noise texture, cursor-following radial spotlight, optional Chromium SVG refraction).
- **Original DZNOVA Brand Suite**: Custom D+Z+Streaming Waves+Orbital Ring+Nova Burst symbol in Horizontal, Standalone Icon, Compact, Monochrome, Light, Dark, SVG master, Windows `.ico`, `favicon.ico`, and Animated Logo Intro.
- **50 Original 3D Liquid Glass Icons**: Individual typed React SVG components under `src/components/icons/glyphs/` with 3D pointer tilt, idle float, click bounce/pulse, and selected glow.
- **Aurora Atmosphere**: Floating clouds, ice crystals, aurora light curtains, glass spheres, and glowing particles with Reduced Motion and Low Performance modes.
- **Bilingual Arabic RTL & English LTR + Dark/Light Themes**: Full `Cairo` / `Tajawal` + `Inter` / `Space Grotesk` typography and `tabular-nums` telemetry.

## Quick Start

```bash
npm install
npm run dev
```

## Production Build & GitHub Pages

```bash
npm run build
```

Push to `main` on GitHub and enable **Settings → Pages → Source: GitHub Actions** to deploy automatically via `.github/workflows/deploy.yml`.
