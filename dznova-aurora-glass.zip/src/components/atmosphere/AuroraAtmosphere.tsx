import React from 'react';

interface AuroraAtmosphereProps {
  lowPerf: boolean;
  theme: 'dark' | 'light';
}

export const AuroraAtmosphere: React.FC<AuroraAtmosphereProps> = ({ lowPerf, theme }) => {
  const isDark = theme === 'dark';

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 -z-10 overflow-hidden pointer-events-none select-none"
      style={{
        background: isDark
          ? 'radial-gradient(120% 80% at 15% 10%, #10244d 0%, #071024 45%, #040814 100%)'
          : 'radial-gradient(120% 80% at 15% 10%, #e0f2fe 0%, #eff6ff 50%, #f5f3ff 100%)',
      }}
    >
      {/* Optional Chromium progressive SVG refraction filter */}
      <svg className="hidden" aria-hidden="true">
        <filter id="aurora-refract">
          <feTurbulence type="fractalNoise" baseFrequency="0.012" numOctaves="2" result="noise" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="3" />
        </filter>
      </svg>

      {/* Aurora Light Curtains */}
      <div
        className="aurora-curtain absolute -top-32 -left-24 h-[520px] w-[72vw] rounded-full blur-[110px]"
        style={{
          background: isDark
            ? 'linear-gradient(115deg, rgba(34,211,238,0.28), rgba(59,130,246,0.22), rgba(139,92,246,0.26))'
            : 'linear-gradient(115deg, rgba(56,189,248,0.32), rgba(99,102,241,0.18), rgba(168,85,247,0.2))',
        }}
      />
      <div
        className="aurora-curtain absolute top-1/3 -right-24 h-[460px] w-[60vw] rounded-full blur-[120px]"
        style={{
          animationDelay: '-6s',
          background: isDark
            ? 'linear-gradient(240deg, rgba(139,92,246,0.26), rgba(14,165,233,0.2), transparent)'
            : 'linear-gradient(240deg, rgba(192,132,252,0.26), rgba(56,189,248,0.22), transparent)',
        }}
      />

      {/* Soft Floating Clouds & Mist */}
      {!lowPerf && (
        <>
          <div className="aurora-cloud absolute top-[14%] left-[12%] h-44 w-96 rounded-full bg-cyan-300/10 blur-3xl" />
          <div
            className="aurora-cloud absolute bottom-[12%] right-[10%] h-52 w-[28rem] rounded-full bg-violet-400/12 blur-3xl"
            style={{ animationDelay: '-10s' }}
          />
          {/* Floating Translucent Ice Crystals & Glass Spheres */}
          <div className="aurora-crystal absolute top-[22%] right-[14%] h-14 w-14 rounded-2xl rotate-12 border border-white/25 bg-white/10 backdrop-blur-md shadow-lg" />
          <div
            className="aurora-crystal absolute bottom-[24%] left-[8%] h-10 w-10 rounded-full border border-cyan-200/30 bg-gradient-to-br from-cyan-300/25 to-violet-400/10"
            style={{ animationDelay: '-4s' }}
          />
          <div
            className="aurora-crystal absolute top-[60%] right-[28%] h-7 w-7 rounded-lg rotate-45 border border-violet-200/25 bg-white/10"
            style={{ animationDelay: '-8s' }}
          />
        </>
      )}
    </div>
  );
};
