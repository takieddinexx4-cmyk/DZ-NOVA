import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

function AuroraCrystalCore() {
  const meshRef = useRef<THREE.Mesh>(null);
  const ringRef = useRef<THREE.Mesh>(null);

  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.35;
      meshRef.current.rotation.x += delta * 0.14;
    }
    if (ringRef.current) {
      ringRef.current.rotation.z -= delta * 0.28;
    }
  });

  return (
    <group>
      <mesh ref={meshRef}>
        <octahedronGeometry args={[1.15, 0]} />
        <meshPhysicalMaterial
          color="#38bdf8"
          emissive="#1e3a8a"
          emissiveIntensity={0.4}
          roughness={0.12}
          metalness={0.25}
          transmission={0.78}
          thickness={1.4}
          transparent
          opacity={0.92}
        />
      </mesh>
      <mesh ref={ringRef} rotation={[1.1, 0.35, 0]}>
        <torusGeometry args={[1.75, 0.045, 16, 64]} />
        <meshStandardMaterial color="#a78bfa" emissive="#22d3ee" emissiveIntensity={0.8} />
      </mesh>
    </group>
  );
}

/**
 * Dynamically loaded ONLY inside the Dashboard Hero (never inside OBS overlays).
 */
export const DashboardHero3D: React.FC = () => {
  return (
    <div className="h-36 w-36 shrink-0 rounded-3xl overflow-hidden pointer-events-none" aria-hidden="true">
      <Canvas camera={{ position: [0, 0, 4.4], fov: 42 }} dpr={[1, 1.5]}>
        <ambientLight intensity={0.7} />
        <pointLight position={[4, 4, 4]} intensity={1.8} color="#67e8f9" />
        <pointLight position={[-4, -3, 3]} intensity={1.2} color="#a78bfa" />
        <AuroraCrystalCore />
      </Canvas>
    </div>
  );
};

export default DashboardHero3D;
