import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DznovaLogo } from './DznovaLogo';
import { AURORA_EASE } from '../../motion/config';

interface DznovaLogoIntroProps {
  visible: boolean;
  reducedMotion: boolean;
  onComplete: () => void;
}

export const DznovaLogoIntro: React.FC<DznovaLogoIntroProps> = ({
  visible,
  reducedMotion,
  onComplete,
}) => {
  useEffect(() => {
    if (!visible) return;
    const timer = window.setTimeout(onComplete, reducedMotion ? 900 : 2400);
    return () => window.clearTimeout(timer);
  }, [visible, reducedMotion, onComplete]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.45 }}
          onClick={onComplete}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#040814]/92 backdrop-blur-2xl cursor-pointer"
        >
          <motion.div
            initial={reducedMotion ? { opacity: 1 } : { scale: 0.72, opacity: 0, rotate: -8 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            transition={{ duration: 0.85, ease: AURORA_EASE }}
            className="relative flex flex-col items-center gap-5"
          >
            <div className="absolute -inset-12 rounded-full bg-gradient-to-tr from-cyan-500/30 via-blue-500/20 to-violet-500/30 blur-3xl pointer-events-none" />
            <DznovaLogo variant="icon" size={112} />
            <motion.div
              initial={reducedMotion ? { opacity: 1 } : { opacity: 0, y: 14, letterSpacing: '0.45em' }}
              animate={{ opacity: 1, y: 0, letterSpacing: '0.26em' }}
              transition={{ delay: 0.35, duration: 0.75, ease: AURORA_EASE }}
              className="font-display text-4xl font-bold text-white"
              dir="ltr"
            >
              DZ<span className="bg-gradient-to-r from-cyan-300 via-blue-400 to-violet-400 bg-clip-text text-transparent">NOVA</span>
            </motion.div>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.8 }}
              transition={{ delay: 0.7, duration: 0.5 }}
              className="text-xs tracking-[0.34em] text-cyan-200 uppercase"
            >
              AURORA GLASS UNIVERSE
            </motion.p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
