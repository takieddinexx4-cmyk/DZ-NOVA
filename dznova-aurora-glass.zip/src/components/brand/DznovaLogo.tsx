import React, { useId } from 'react';

export type LogoVariant = 'horizontal' | 'icon' | 'compact' | 'mono-light' | 'mono-dark' | 'light' | 'dark';

interface DznovaLogoProps {
  variant?: LogoVariant;
  size?: number;
  className?: string;
}

export const DznovaLogo: React.FC<DznovaLogoProps> = ({
  variant = 'horizontal',
  size = 44,
  className = '',
}) => {
  const uid = `dzn-logo-${useId().replace(/:/g, '')}`;
  const isMono = variant === 'mono-light' || variant === 'mono-dark';
  const monoStroke = variant === 'mono-dark' ? '#0B1226' : '#FFFFFF';
  const isLight = variant === 'light';

  const symbol = (
    <svg
      width={size}
      height={size}
      viewBox="0 0 128 128"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="DZNOVA Symbol"
      className="shrink-0"
    >
      {isMono ? (
        <>
          <rect x="10" y="10" width="108" height="108" rx="30" stroke={monoStroke} strokeWidth="3.5" strokeOpacity="0.9" />
          <ellipse cx="64" cy="64" rx="46" ry="20" transform="rotate(-28 64 64)" stroke={monoStroke} strokeWidth="2.5" strokeOpacity="0.55" />
          <path d="M28 34 H56 C74 34 86 45 86 64 C86 83 74 94 56 94 H28 V34 Z" stroke={monoStroke} strokeWidth="7" strokeLinejoin="round" />
          <path d="M52 44 H96 L56 84 H98" stroke={monoStroke} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M98 30 C105 37 108 46 108 55" stroke={monoStroke} strokeWidth="3.5" strokeLinecap="round" strokeOpacity="0.8" />
          <path d="M94 34 L97 41 L104 44 L97 47 L94 54 L91 47 L84 44 L91 41 Z" fill={monoStroke} />
        </>
      ) : (
        <>
          <defs>
            <linearGradient id={`${uid}-bg`} x1="12" y1="8" x2="116" y2="120" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor={isLight ? '#E0F2FE' : '#0F1D42'} />
              <stop offset="52%" stopColor={isLight ? '#BAE6FD' : '#13295E'} />
              <stop offset="100%" stopColor={isLight ? '#DDD6FE' : '#091024'} />
            </linearGradient>
            <radialGradient id={`${uid}-aurora`} cx="30%" cy="22%" r="78%">
              <stop offset="0%" stopColor="#38BDF8" stopOpacity="0.58" />
              <stop offset="52%" stopColor="#6366F1" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#0EA5E9" stopOpacity="0" />
            </radialGradient>
            <linearGradient id={`${uid}-d`} x1="24" y1="30" x2="86" y2="98" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#E0F2FE" />
              <stop offset="40%" stopColor="#38BDF8" />
              <stop offset="100%" stopColor="#7C3AED" />
            </linearGradient>
            <linearGradient id={`${uid}-z`} x1="48" y1="38" x2="104" y2="92" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="32%" stopColor="#67E8F9" />
              <stop offset="72%" stopColor="#3B82F6" />
              <stop offset="100%" stopColor="#A855F7" />
            </linearGradient>
            <linearGradient id={`${uid}-spec`} x1="20" y1="12" x2="72" y2="62" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.62" />
              <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
            </linearGradient>
          </defs>
          <rect x="8" y="8" width="112" height="112" rx="30" fill={`url(#${uid}-bg)`} />
          <rect x="8" y="8" width="112" height="112" rx="30" fill={`url(#${uid}-aurora)`} />
          <rect x="10" y="10" width="108" height="108" rx="28" stroke={isLight ? 'rgba(59,130,246,0.35)' : 'rgba(186,230,253,0.45)'} strokeWidth="2" />
          <path d="M18 36 C18 22 28 14 44 14 H86 C96 14 104 18 108 26 C88 38 56 44 18 42 Z" fill={`url(#${uid}-spec)`} />
          <ellipse cx="64" cy="64" rx="46" ry="18" transform="rotate(-26 64 64)" stroke="#67E8F9" strokeOpacity="0.78" strokeWidth="2.8" />
          <path d="M90 25 C99 33 104 43 105 54" stroke="#67E8F9" strokeWidth="3.2" strokeLinecap="round" />
          <path d="M97 19 C108 29 113 41 114 55" stroke="#A78BFA" strokeWidth="2.2" strokeLinecap="round" strokeOpacity="0.6" />
          <path d="M27 35 H54 C72 35 84 46 84 64 C84 82 72 93 54 93 H27 C24.8 93 23 91.2 23 89 V39 C23 36.8 24.8 35 27 35 Z" fill={`url(#${uid}-d)`} fillOpacity="0.24" stroke={`url(#${uid}-d)`} strokeWidth="7.5" strokeLinejoin="round" />
          <path d="M49 44 H95 L53 84 H97" stroke={`url(#${uid}-z)`} strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M93 31 L95.6 40.4 L105 43 L95.6 45.6 L93 55 L90.4 45.6 L81 43 L90.4 40.4 Z" fill="#FFFFFF" />
        </>
      )}
    </svg>
  );

  if (variant === 'icon' || isMono) return <span className={`inline-flex ${className}`}>{symbol}</span>;

  const textColor = isLight ? 'text-slate-900' : 'text-white';
  return (
    <span className={`inline-flex items-center gap-3 select-none ${className}`} dir="ltr">
      {symbol}
      <span className="flex flex-col leading-none">
        <span
          className={`font-display font-bold tracking-[0.2em] ${
            variant === 'compact' ? 'text-lg' : 'text-2xl'
          } ${textColor}`}
        >
          DZ<span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-violet-400 bg-clip-text text-transparent">NOVA</span>
        </span>
        {variant !== 'compact' && (
          <span className="mt-1 text-[10px] font-semibold tracking-[0.28em] text-cyan-400/80 uppercase">
            AURORA GLASS
          </span>
        )}
      </span>
    </span>
  );
};
