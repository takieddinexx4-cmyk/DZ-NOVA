import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AURORA_EASE } from '../../motion/config';

export const GlassCard: React.FC<{
  children: React.ReactNode;
  className?: string;
  spotlight?: boolean;
  onContextMenu?: (e: React.MouseEvent<HTMLDivElement>) => void;
}> = ({ children, className = '', spotlight = true, onContextMenu }) => {
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!spotlight) return;
    const rect = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty('--mx', `${e.clientX - rect.left}px`);
    e.currentTarget.style.setProperty('--my', `${e.clientY - rect.top}px`);
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      onContextMenu={onContextMenu}
      className={`aurora-glass rounded-3xl p-5 ${spotlight ? 'aurora-spotlight' : ''} ${className}`}
    >
      {children}
    </div>
  );
};

export const GlassToggle: React.FC<{
  checked: boolean;
  onChange: (next: boolean) => void;
  label: string;
}> = ({ checked, onChange, label }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    onClick={() => onChange(!checked)}
    className="flex items-center justify-between gap-3 w-full text-start py-1.5 group"
  >
    <span className="text-sm font-medium">{label}</span>
    <span
      className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full border transition-colors ${
        checked
          ? 'bg-gradient-to-r from-cyan-400 to-violet-500 border-cyan-300/60'
          : 'bg-slate-500/30 border-white/15'
      }`}
    >
      <span
        className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${
          checked ? 'translate-x-5 rtl:-translate-x-5' : 'translate-x-1 rtl:-translate-x-1'
        }`}
      />
    </span>
  </button>
);

export const AnimatedCounter: React.FC<{ value: number; suffix?: string }> = ({ value, suffix = '' }) => {
  const [display, setDisplay] = useState(value);
  useEffect(() => {
    const start = display;
    const diff = value - start;
    if (diff === 0) return;
    let frame = 0;
    const total = 18;
    const id = window.setInterval(() => {
      frame += 1;
      setDisplay(Math.round(start + (diff * frame) / total));
      if (frame >= total) window.clearInterval(id);
    }, 16);
    return () => window.clearInterval(id);
  }, [value]);

  return (
    <span className="tabular-nums">
      {display.toLocaleString()}
      {suffix}
    </span>
  );
};

export const GlassModal: React.FC<{
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}> = ({ open, title, onClose, children }) => (
  <AnimatePresence>
    {open && (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-md p-4"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 14 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 10 }}
          transition={{ duration: 0.25, ease: AURORA_EASE }}
          onClick={(e) => e.stopPropagation()}
          className="aurora-glass aurora-glass-strong w-full max-w-lg rounded-3xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">{title}</h3>
            <button
              type="button"
              onClick={onClose}
              className="crystal-btn px-3 py-1 text-xs aurora-glass rounded-xl"
            >
              ✕
            </button>
          </div>
          {children}
        </motion.div>
      </motion.div>
    )}
  </AnimatePresence>
);
