import React, { useId, useRef, useState } from 'react';

export type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | number;

const SIZE_MAP: Record<Exclude<IconSize, number>, number> = {
  xs: 18,
  sm: 24,
  md: 32,
  lg: 44,
  xl: 56,
  '2xl': 72,
};

export interface AuroraIconProps {
  size?: IconSize;
  selected?: boolean;
  interactive?: boolean;
  idleFloat?: boolean;
  className?: string;
  onClick?: (e: React.MouseEvent<HTMLSpanElement>) => void;
  title?: string;
}

interface IconBaseInternalProps extends AuroraIconProps {
  gradFrom: string;
  gradMid: string;
  gradTo: string;
  accent: string;
  ariaLabel: string;
  children: (id: string) => React.ReactNode;
}

export const IconBase: React.FC<IconBaseInternalProps> = ({
  size = 'md',
  selected = false,
  interactive = true,
  idleFloat = false,
  className = '',
  onClick,
  title,
  gradFrom,
  gradMid,
  gradTo,
  accent,
  ariaLabel,
  children,
}) => {
  const rawId = useId().replace(/:/g, '');
  const uid = `dzn-ico-${rawId}`;
  const px = typeof size === 'number' ? size : SIZE_MAP[size];
  const ref = useRef<HTMLSpanElement>(null);
  const [tilt, setTilt] = useState({ rx: 0, ry: 0 });
  const [pulsing, setPulsing] = useState(false);

  const handleMove = (e: React.MouseEvent<HTMLSpanElement>) => {
    if (!interactive || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width - 0.5;
    const ny = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ rx: -ny * 14, ry: nx * 14 });
  };

  const handleLeave = () => setTilt({ rx: 0, ry: 0 });

  const handleClick = (e: React.MouseEvent<HTMLSpanElement>) => {
    if (interactive) {
      setPulsing(true);
      window.setTimeout(() => setPulsing(false), 380);
    }
    onClick?.(e);
  };

  return (
    <span
      ref={ref}
      title={title ?? ariaLabel}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      onClick={handleClick}
      className={[
        'dzn-icon-wrap',
        interactive ? 'dzn-icon-interactive' : '',
        idleFloat ? 'dzn-icon-float' : '',
        selected ? 'dzn-icon-selected' : '',
        pulsing ? 'dzn-icon-pulse' : '',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      style={{
        width: px,
        height: px,
        transform:
          tilt.rx || tilt.ry
            ? `perspective(260px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg) translateY(-2px) scale(1.07)`
            : undefined,
      }}
    >
      <svg
        width={px}
        height={px}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        role="img"
        aria-label={ariaLabel}
        className="dzn-icon-svg"
      >
        <defs>
          <linearGradient id={`${uid}-bg`} x1="6" y1="4" x2="58" y2="60" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor={gradFrom} />
            <stop offset="52%" stopColor={gradMid} />
            <stop offset="100%" stopColor={gradTo} />
          </linearGradient>
          <linearGradient id={`${uid}-fg`} x1="16" y1="14" x2="48" y2="50" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="55%" stopColor={accent} />
            <stop offset="100%" stopColor="#E0F2FE" />
          </linearGradient>
          <linearGradient id={`${uid}-spec`} x1="10" y1="6" x2="36" y2="32" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.62" />
            <stop offset="55%" stopColor="#FFFFFF" stopOpacity="0.14" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </linearGradient>
          <radialGradient id={`${uid}-ao`} cx="50%" cy="95%" r="60%">
            <stop offset="0%" stopColor="#020617" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#020617" stopOpacity="0" />
          </radialGradient>
        </defs>
        {/* 3D Squircle Crystal Shell */}
        <rect x="4" y="4" width="56" height="56" rx="16.5" fill={`url(#${uid}-bg)`} />
        <rect x="4" y="4" width="56" height="56" rx="16.5" fill={`url(#${uid}-ao)`} />
        {/* Top-left liquid glass specular reflection */}
        <path
          d="M9 21 C9 12 14 7 23 7 H43 C49 7 53 9.5 55 14 C44 21 28 24 9 23 Z"
          fill={`url(#${uid}-spec)`}
        />
        {/* Inner crystal rim highlight */}
        <rect
          x="5"
          y="5"
          width="54"
          height="54"
          rx="15.5"
          stroke="#FFFFFF"
          strokeOpacity="0.34"
          strokeWidth="1.4"
        />
        {/* Unique Icon Metaphor */}
        <g>{children(uid)}</g>
      </svg>
    </span>
  );
};
