import React from 'react';
import { AuroraIconProps } from './IconBase';
import { DashboardIcon } from './glyphs/DashboardIcon';
import { LiveStreamingIcon } from './glyphs/LiveStreamingIcon';
import { ObsIcon } from './glyphs/ObsIcon';
import { ScenesIcon } from './glyphs/ScenesIcon';
import { OverlaysIcon } from './glyphs/OverlaysIcon';
import { GiftsIcon } from './glyphs/GiftsIcon';
import { FollowersIcon } from './glyphs/FollowersIcon';
import { ChatIcon } from './glyphs/ChatIcon';
import { AlertsIcon } from './glyphs/AlertsIcon';
import { AudioIcon } from './glyphs/AudioIcon';
import { TtsIcon } from './glyphs/TtsIcon';
import { AnalyticsIcon } from './glyphs/AnalyticsIcon';
import { LeaderboardsIcon } from './glyphs/LeaderboardsIcon';
import { WilayaBattleIcon } from './glyphs/WilayaBattleIcon';
import { PollsIcon } from './glyphs/PollsIcon';
import { QuizIcon } from './glyphs/QuizIcon';
import { GiveawayIcon } from './glyphs/GiveawayIcon';
import { WheelIcon } from './glyphs/WheelIcon';
import { CountdownIcon } from './glyphs/CountdownIcon';
import { GoalsIcon } from './glyphs/GoalsIcon';
import { AutomationIcon } from './glyphs/AutomationIcon';
import { ChatbotIcon } from './glyphs/ChatbotIcon';
import { ConnectionsIcon } from './glyphs/ConnectionsIcon';
import { SecurityIcon } from './glyphs/SecurityIcon';
import { SettingsIcon } from './glyphs/SettingsIcon';
import { ProfileIcon } from './glyphs/ProfileIcon';
import { NotificationsIcon } from './glyphs/NotificationsIcon';
import { CloudSyncIcon } from './glyphs/CloudSyncIcon';
import { StorageIcon } from './glyphs/StorageIcon';
import { PerformanceIcon } from './glyphs/PerformanceIcon';
import { AppearanceIcon } from './glyphs/AppearanceIcon';
import { LanguageIcon } from './glyphs/LanguageIcon';
import { SupportIcon } from './glyphs/SupportIcon';
import { IntegrationsIcon } from './glyphs/IntegrationsIcon';
import { GamingIcon } from './glyphs/GamingIcon';
import { MicrophoneIcon } from './glyphs/MicrophoneIcon';
import { CameraIcon } from './glyphs/CameraIcon';
import { MusicIcon } from './glyphs/MusicIcon';
import { StatisticsIcon } from './glyphs/StatisticsIcon';
import { LiveControlsIcon } from './glyphs/LiveControlsIcon';
import { DesktopCompanionIcon } from './glyphs/DesktopCompanionIcon';
import { ExportIcon } from './glyphs/ExportIcon';
import { ImportIcon } from './glyphs/ImportIcon';
import { SearchIcon } from './glyphs/SearchIcon';
import { HelpIcon } from './glyphs/HelpIcon';
import { ThemeSelectorIcon } from './glyphs/ThemeSelectorIcon';
import { LightModeIcon } from './glyphs/LightModeIcon';
import { DarkModeIcon } from './glyphs/DarkModeIcon';
import { AccountManagementIcon } from './glyphs/AccountManagementIcon';
import { SubscriptionIcon } from './glyphs/SubscriptionIcon';

export { IconBase } from './IconBase';
export type { AuroraIconProps, IconSize } from './IconBase';
export { DashboardIcon } from './glyphs/DashboardIcon';
export { LiveStreamingIcon } from './glyphs/LiveStreamingIcon';
export { ObsIcon } from './glyphs/ObsIcon';
export { ScenesIcon } from './glyphs/ScenesIcon';
export { OverlaysIcon } from './glyphs/OverlaysIcon';
export { GiftsIcon } from './glyphs/GiftsIcon';
export { FollowersIcon } from './glyphs/FollowersIcon';
export { ChatIcon } from './glyphs/ChatIcon';
export { AlertsIcon } from './glyphs/AlertsIcon';
export { AudioIcon } from './glyphs/AudioIcon';
export { TtsIcon } from './glyphs/TtsIcon';
export { AnalyticsIcon } from './glyphs/AnalyticsIcon';
export { LeaderboardsIcon } from './glyphs/LeaderboardsIcon';
export { WilayaBattleIcon } from './glyphs/WilayaBattleIcon';
export { PollsIcon } from './glyphs/PollsIcon';
export { QuizIcon } from './glyphs/QuizIcon';
export { GiveawayIcon } from './glyphs/GiveawayIcon';
export { WheelIcon } from './glyphs/WheelIcon';
export { CountdownIcon } from './glyphs/CountdownIcon';
export { GoalsIcon } from './glyphs/GoalsIcon';
export { AutomationIcon } from './glyphs/AutomationIcon';
export { ChatbotIcon } from './glyphs/ChatbotIcon';
export { ConnectionsIcon } from './glyphs/ConnectionsIcon';
export { SecurityIcon } from './glyphs/SecurityIcon';
export { SettingsIcon } from './glyphs/SettingsIcon';
export { ProfileIcon } from './glyphs/ProfileIcon';
export { NotificationsIcon } from './glyphs/NotificationsIcon';
export { CloudSyncIcon } from './glyphs/CloudSyncIcon';
export { StorageIcon } from './glyphs/StorageIcon';
export { PerformanceIcon } from './glyphs/PerformanceIcon';
export { AppearanceIcon } from './glyphs/AppearanceIcon';
export { LanguageIcon } from './glyphs/LanguageIcon';
export { SupportIcon } from './glyphs/SupportIcon';
export { IntegrationsIcon } from './glyphs/IntegrationsIcon';
export { GamingIcon } from './glyphs/GamingIcon';
export { MicrophoneIcon } from './glyphs/MicrophoneIcon';
export { CameraIcon } from './glyphs/CameraIcon';
export { MusicIcon } from './glyphs/MusicIcon';
export { StatisticsIcon } from './glyphs/StatisticsIcon';
export { LiveControlsIcon } from './glyphs/LiveControlsIcon';
export { DesktopCompanionIcon } from './glyphs/DesktopCompanionIcon';
export { ExportIcon } from './glyphs/ExportIcon';
export { ImportIcon } from './glyphs/ImportIcon';
export { SearchIcon } from './glyphs/SearchIcon';
export { HelpIcon } from './glyphs/HelpIcon';
export { ThemeSelectorIcon } from './glyphs/ThemeSelectorIcon';
export { LightModeIcon } from './glyphs/LightModeIcon';
export { DarkModeIcon } from './glyphs/DarkModeIcon';
export { AccountManagementIcon } from './glyphs/AccountManagementIcon';
export { SubscriptionIcon } from './glyphs/SubscriptionIcon';

export interface IconRegistryItem {
  id: string;
  name: string;
  nameAr: string;
  category: 'Core' | 'Broadcast' | 'Engagement' | 'Media' | 'Data' | 'Interactive' | 'Intelligence' | 'System' | 'Customization' | 'Account' | 'Actions';
  component: React.FC<AuroraIconProps>;
}

export const DZNOVA_ICON_REGISTRY: IconRegistryItem[] = [
  { id: 'dashboard', name: 'Dashboard', nameAr: 'لوحة التحكم', category: 'Core', component: DashboardIcon },
  { id: 'live-streaming', name: 'Live Streaming', nameAr: 'البث المباشر', category: 'Broadcast', component: LiveStreamingIcon },
  { id: 'obs', name: 'OBS Studio', nameAr: 'أو بي إس', category: 'Broadcast', component: ObsIcon },
  { id: 'scenes', name: 'Scenes', nameAr: 'المشاهد', category: 'Broadcast', component: ScenesIcon },
  { id: 'overlays', name: 'Overlays', nameAr: 'الطبقات', category: 'Broadcast', component: OverlaysIcon },
  { id: 'gifts', name: 'Gifts', nameAr: 'الهدايا', category: 'Engagement', component: GiftsIcon },
  { id: 'followers', name: 'Followers', nameAr: 'المتابعون', category: 'Engagement', component: FollowersIcon },
  { id: 'chat', name: 'Live Chat', nameAr: 'الدردشة', category: 'Engagement', component: ChatIcon },
  { id: 'alerts', name: 'Alerts', nameAr: 'التنبيهات', category: 'Engagement', component: AlertsIcon },
  { id: 'audio', name: 'Audio Mixer', nameAr: 'الصوت', category: 'Media', component: AudioIcon },
  { id: 'tts', name: 'Text-to-Speech', nameAr: 'تحويل النص لصوت', category: 'Media', component: TtsIcon },
  { id: 'analytics', name: 'Analytics', nameAr: 'التحليلات', category: 'Data', component: AnalyticsIcon },
  { id: 'leaderboards', name: 'Leaderboards', nameAr: 'لوحة الصدارة', category: 'Data', component: LeaderboardsIcon },
  { id: 'wilaya-battle', name: 'Wilaya Battle', nameAr: 'تحدي الولايات', category: 'Interactive', component: WilayaBattleIcon },
  { id: 'polls', name: 'Live Polls', nameAr: 'الاستطلاعات', category: 'Interactive', component: PollsIcon },
  { id: 'quiz', name: 'Quiz Arena', nameAr: 'المسابقات', category: 'Interactive', component: QuizIcon },
  { id: 'giveaway', name: 'Giveaway', nameAr: 'السحوبات', category: 'Interactive', component: GiveawayIcon },
  { id: 'wheel', name: 'Spin Wheel', nameAr: 'عجلة الحظ', category: 'Interactive', component: WheelIcon },
  { id: 'countdown', name: 'Countdown', nameAr: 'العد التنازلي', category: 'Interactive', component: CountdownIcon },
  { id: 'goals', name: 'Stream Goals', nameAr: 'الأهداف', category: 'Interactive', component: GoalsIcon },
  { id: 'automation', name: 'Automation', nameAr: 'الأتمتة', category: 'Intelligence', component: AutomationIcon },
  { id: 'chatbot', name: 'AI Chatbot', nameAr: 'بوت الدردشة', category: 'Intelligence', component: ChatbotIcon },
  { id: 'connections', name: 'Connections', nameAr: 'الاتصالات', category: 'System', component: ConnectionsIcon },
  { id: 'security', name: 'Security', nameAr: 'الأمان', category: 'System', component: SecurityIcon },
  { id: 'settings', name: 'Settings', nameAr: 'الإعدادات', category: 'System', component: SettingsIcon },
  { id: 'profile', name: 'Profile', nameAr: 'الملف الشخصي', category: 'Account', component: ProfileIcon },
  { id: 'notifications', name: 'Notifications', nameAr: 'الإشعارات', category: 'System', component: NotificationsIcon },
  { id: 'cloud-sync', name: 'Cloud Sync', nameAr: 'المزامنة السحابية', category: 'System', component: CloudSyncIcon },
  { id: 'storage', name: 'Storage', nameAr: 'التخزين', category: 'System', component: StorageIcon },
  { id: 'performance', name: 'Performance', nameAr: 'الأداء', category: 'System', component: PerformanceIcon },
  { id: 'appearance', name: 'Appearance', nameAr: 'المظهر', category: 'Customization', component: AppearanceIcon },
  { id: 'language', name: 'Language', nameAr: 'اللغة', category: 'Customization', component: LanguageIcon },
  { id: 'support', name: 'Support', nameAr: 'الدعم الفني', category: 'System', component: SupportIcon },
  { id: 'integrations', name: 'Integrations', nameAr: 'التكاملات', category: 'System', component: IntegrationsIcon },
  { id: 'gaming', name: 'Gaming', nameAr: 'الألعاب', category: 'Media', component: GamingIcon },
  { id: 'microphone', name: 'Microphone', nameAr: 'الميكروفون', category: 'Media', component: MicrophoneIcon },
  { id: 'camera', name: 'Camera', nameAr: 'الكاميرا', category: 'Media', component: CameraIcon },
  { id: 'music', name: 'Music', nameAr: 'الموسيقى', category: 'Media', component: MusicIcon },
  { id: 'statistics', name: 'Statistics', nameAr: 'الإحصائيات', category: 'Data', component: StatisticsIcon },
  { id: 'live-controls', name: 'Live Controls', nameAr: 'تحكم البث', category: 'Broadcast', component: LiveControlsIcon },
  { id: 'desktop-companion', name: 'Desktop Companion', nameAr: 'تطبيق سطح المكتب', category: 'System', component: DesktopCompanionIcon },
  { id: 'export', name: 'Export', nameAr: 'تصدير', category: 'Actions', component: ExportIcon },
  { id: 'import', name: 'Import', nameAr: 'استيراد', category: 'Actions', component: ImportIcon },
  { id: 'search', name: 'Search', nameAr: 'بحث', category: 'Actions', component: SearchIcon },
  { id: 'help', name: 'Help Center', nameAr: 'المساعدة', category: 'System', component: HelpIcon },
  { id: 'theme-selector', name: 'Theme Selector', nameAr: 'اختيار السمة', category: 'Customization', component: ThemeSelectorIcon },
  { id: 'light-mode', name: 'Light Mode', nameAr: 'الوضع النهاري', category: 'Customization', component: LightModeIcon },
  { id: 'dark-mode', name: 'Dark Mode', nameAr: 'الوضع الليلي', category: 'Customization', component: DarkModeIcon },
  { id: 'account-management', name: 'Account Management', nameAr: 'إدارة الحساب', category: 'Account', component: AccountManagementIcon },
  { id: 'subscription', name: 'Subscription', nameAr: 'الاشتراك', category: 'Account', component: SubscriptionIcon },
];
