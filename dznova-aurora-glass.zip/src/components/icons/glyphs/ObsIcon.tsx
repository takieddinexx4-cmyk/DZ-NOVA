import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const ObsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#1E293B"
    gradMid="#334155"
    gradTo="#0F172A"
    accent="#38BDF8"
    ariaLabel="OBS Studio"
  >
    {(id) => (
      <>
        <circle cx="32" cy="32" r="17" fill="#FFFFFF" fillOpacity="0.14" stroke="#38BDF8" strokeWidth="2.2"/>
        <path d="M32 18 C39 18 42 25 37 30 C33 34 26 32 25 26 C24 21 28 18 32 18 Z" fill={`url(#${id}-fg)`}/>
        <path d="M44 39 C40 45 33 44 31 38 C29 33 35 28 40 30 C45 32 46 36 44 39 Z" fill="#FFFFFF" fillOpacity="0.88"/>
        <path d="M20 39 C17 33 21 27 27 29 C32 30 33 37 29 41 C25 45 22 42 20 39 Z" fill="#38BDF8" fillOpacity="0.9"/>
      </>
    )}
  </IconBase>
);
