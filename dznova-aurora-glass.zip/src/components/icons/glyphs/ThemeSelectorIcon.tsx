import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const ThemeSelectorIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#F59E0B"
    gradMid="#6366F1"
    gradTo="#1E1B4B"
    accent="#FDE68A"
    ariaLabel="Theme Selector"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="32" r="15" fill="#FFFFFF" fillOpacity="0.22" stroke="#FFFFFF" strokeWidth="2.2"/>
        <path d="M32 17 A15 15 0 0 1 32 47 Z" fill={`url(#${id}-fg)`}/>
        <circle cx="24" cy="32" r="3" fill="#FDE047"/>
      </>
    )}
  </IconBase>
);
