import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const SupportIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#14B8A6"
    gradTo="#134E4A"
    accent="#99F6E4"
    ariaLabel="Support"
  >
    {(id) => (
      <>
        <path d="M18 33 V29 C18 21.3 24.3 15 32 15 C39.7 15 46 21.3 46 29 V33" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <rect x="14" y="30" width="7" height="13" rx="3.5" fill={`url(#${id}-fg)`}/>
        <rect x="43" y="30" width="7" height="13" rx="3.5" fill={`url(#${id}-fg)`}/>
        <path d="M46 42 C46 46 42 48 35 48" stroke="#FFFFFF" strokeWidth="2.6" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
