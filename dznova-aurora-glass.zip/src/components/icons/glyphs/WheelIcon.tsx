import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const WheelIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#EC4899"
    gradMid="#8B5CF6"
    gradTo="#1E1B4B"
    accent="#F5D0FE"
    ariaLabel="Spin Wheel"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="34" r="16" fill="#FFFFFF" fillOpacity="0.24" stroke="#FFFFFF" strokeWidth="2.4"/>
        <path d="M32 18 V50 M16 34 H48 M20.7 22.7 L43.3 45.3 M43.3 22.7 L20.7 45.3" stroke="#FFFFFF" strokeOpacity="0.7" strokeWidth="2"/>
        <circle cx="32" cy="34" r="5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="2"/>
        <path d="M32 12 L36 19 H28 Z" fill="#67E8F9"/>
      </>
    )}
  </IconBase>
);
