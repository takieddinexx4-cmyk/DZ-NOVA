import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const DashboardIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#2563EB"
    gradTo="#1E1B4B"
    accent="#67E8F9"
    ariaLabel="Dashboard"
  >
    {(id: string) => (
      <>
        <rect x="16" y="16" width="14" height="14" rx="4.5" fill={`url(#${id}-fg)`} fillOpacity="0.95"/>
        <rect x="34" y="16" width="14" height="10" rx="4" fill="#FFFFFF" fillOpacity="0.72"/>
        <rect x="16" y="34" width="14" height="14" rx="4.5" fill="#FFFFFF" fillOpacity="0.62"/>
        <rect x="34" y="30" width="14" height="18" rx="4.5" fill={`url(#${id}-fg)`}/>
        <circle cx="41" cy="39" r="3" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
