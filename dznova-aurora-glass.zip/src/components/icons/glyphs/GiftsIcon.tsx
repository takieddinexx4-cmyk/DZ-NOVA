import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const GiftsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#EC4899"
    gradMid="#DB2777"
    gradTo="#500724"
    accent="#FBCFE8"
    ariaLabel="Gifts"
  >
    {(id: string) => (
      <>
        <rect x="17" y="27" width="30" height="21" rx="5" fill={`url(#${id}-fg)`}/>
        <rect x="14" y="22" width="36" height="8" rx="3.5" fill="#FFFFFF" fillOpacity="0.92"/>
        <rect x="29.5" y="22" width="5" height="26" fill="#F472B6"/>
        <path d="M32 22 C26 14 19 16 22 22 M32 22 C38 14 45 16 42 22" stroke="#FFFFFF" strokeWidth="2.6" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
