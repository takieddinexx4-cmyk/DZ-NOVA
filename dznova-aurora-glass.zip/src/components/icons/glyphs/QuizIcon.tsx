import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const QuizIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#A855F7"
    gradMid="#7E22CE"
    gradTo="#3B0764"
    accent="#E9D5FF"
    ariaLabel="Quiz Arena"
  >
    {(id: string) => (
      <>
        <rect x="16" y="15" width="32" height="34" rx="8" fill="#FFFFFF" fillOpacity="0.25" stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M27 26 C27 22.5 29.5 20.5 32.5 20.5 C35.5 20.5 37.5 22.5 37.5 25 C37.5 27.5 35.5 28.5 33.5 29.5 C32.2 30.2 32 31.2 32 33" stroke="#FFFFFF" strokeWidth="3.4" strokeLinecap="round"/>
        <circle cx="32" cy="39.5" r="2.5" fill="#67E8F9"/>
      </>
    )}
  </IconBase>
);
