import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const GamingIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#7C3AED"
    gradMid="#EC4899"
    gradTo="#3B0764"
    accent="#F5D0FE"
    ariaLabel="Gaming"
  >
    {(id: string) => (
      <>
        <path d="M21 24 H43 C47.5 24 50 28 49 34 L47 43 C46.4 46 43.2 47 41 44.8 L37 41 H27 L23 44.8 C20.8 47 17.6 46 17 43 L15 34 C14 28 16.5 24 21 24 Z" fill={`url(#${id}-fg)`}/>
        <path d="M22 32 H28 M25 29 V35" stroke="#1E1B4B" strokeWidth="2.4" strokeLinecap="round"/>
        <circle cx="39" cy="30.5" r="1.8" fill="#1E1B4B"/>
        <circle cx="42.5" cy="34" r="1.8" fill="#1E1B4B"/>
      </>
    )}
  </IconBase>
);
