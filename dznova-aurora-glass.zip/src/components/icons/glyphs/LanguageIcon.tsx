import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const LanguageIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0284C7"
    gradMid="#2563EB"
    gradTo="#172554"
    accent="#BAE6FD"
    ariaLabel="Language"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="32" r="16" fill="#FFFFFF" fillOpacity="0.22" stroke="#FFFFFF" strokeWidth="2.2"/>
        <ellipse cx="32" cy="32" rx="7.5" ry="16" stroke="#FFFFFF" strokeWidth="1.8"/>
        <line x1="16" y1="32" x2="48" y2="32" stroke="#FFFFFF" strokeWidth="1.8"/>
        <rect x="33" y="34" width="15" height="13" rx="4" fill={`url(#${id}-fg)`}/>
        <text x="40.5" y="43.5" textAnchor="middle" fontSize="9" fontWeight="800" fill="#0F172A">ع</text>
      </>
    )}
  </IconBase>
);
