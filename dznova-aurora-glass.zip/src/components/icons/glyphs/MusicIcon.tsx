import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const MusicIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#EC4899"
    gradMid="#6366F1"
    gradTo="#1E1B4B"
    accent="#FBCFE8"
    ariaLabel="Music"
  >
    {(id: string) => (
      <>
        <path d="M26 42 V21 L44 17 V38" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M26 26 L44 22" stroke="#67E8F9" strokeWidth="2.4"/>
        <circle cx="22" cy="43" r="5" fill={`url(#${id}-fg)`}/>
        <circle cx="40" cy="39" r="5" fill={`url(#${id}-fg)`}/>
      </>
    )}
  </IconBase>
);
