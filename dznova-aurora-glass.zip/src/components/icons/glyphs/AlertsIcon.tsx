import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const AlertsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#F59E0B"
    gradMid="#D97706"
    gradTo="#451A03"
    accent="#FDE68A"
    ariaLabel="Alerts"
  >
    {(id: string) => (
      <>
        <path d="M32 16 C24 16 20 22 20 30 V37 L16 42 H48 L44 37 V30 C44 22 40 16 32 16 Z" fill={`url(#${id}-fg)`}/>
        <circle cx="32" cy="46" r="4" fill="#FFFFFF"/>
        <circle cx="44" cy="20" r="4.5" fill="#F43F5E" stroke="#FFFFFF" strokeWidth="1.6"/>
      </>
    )}
  </IconBase>
);
