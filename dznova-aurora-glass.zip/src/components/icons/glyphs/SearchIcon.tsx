import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const SearchIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#38BDF8"
    gradMid="#6366F1"
    gradTo="#1E1B4B"
    accent="#E0F2FE"
    ariaLabel="Search"
  >
    {(id: string) => (
      <>
        <circle cx="29" cy="29" r="12" fill="#FFFFFF" fillOpacity="0.26" stroke={`url(#${id}-fg)`} strokeWidth="3.8"/>
        <line x1="38.5" y1="38.5" x2="48" y2="48" stroke="#FFFFFF" strokeWidth="4.4" strokeLinecap="round"/>
        <path d="M24 24 A7 7 0 0 1 30 22" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
