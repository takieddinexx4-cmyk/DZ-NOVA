import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const AudioIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#3B82F6"
    gradMid="#1D4ED8"
    gradTo="#172554"
    accent="#93C5FD"
    ariaLabel="Audio Mixer"
  >
    {(id) => (
      <>
        <path d="M16 27 H23 L33 18 V46 L23 37 H16 C14.5 37 14 36 14 34.5 V29.5 C14 28 14.5 27 16 27 Z" fill={`url(#${id}-fg)`}/>
        <path d="M39 24 C43 28 43 36 39 40" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round"/>
        <path d="M44 19 C50 26 50 38 44 45" stroke="#93C5FD" strokeWidth="2.6" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
