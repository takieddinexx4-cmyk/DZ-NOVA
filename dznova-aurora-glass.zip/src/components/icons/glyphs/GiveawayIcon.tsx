import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const GiveawayIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#F97316"
    gradMid="#EA580C"
    gradTo="#431407"
    accent="#FED7AA"
    ariaLabel="Giveaway"
  >
    {(id) => (
      <>
        <path d="M16 25 H48 V31 C45 31 45 37 48 37 V43 H16 V37 C19 37 19 31 16 31 Z" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M32 27 L33.8 31.2 L38.5 31.6 L34.9 34.6 L36 39 L32 36.6 L28 39 L29.1 34.6 L25.5 31.6 L30.2 31.2 Z" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
