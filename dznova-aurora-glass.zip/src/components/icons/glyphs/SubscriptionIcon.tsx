import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const SubscriptionIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#A855F7"
    gradMid="#EC4899"
    gradTo="#3B0764"
    accent="#FDE047"
    ariaLabel="Subscription"
  >
    {(id: string) => (
      <>
        <path d="M22 19 H42 L49 29 L32 48 L15 29 Z" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8" strokeLinejoin="round"/>
        <path d="M15 29 H49 M22 19 L27 29 L32 48 L37 29 L42 19" stroke="#FFFFFF" strokeOpacity="0.65" strokeWidth="1.5"/>
      </>
    )}
  </IconBase>
);
