import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const LiveStreamingIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#F43F5E"
    gradMid="#E11D48"
    gradTo="#4C0519"
    accent="#FDA4AF"
    ariaLabel="Live Streaming"
  >
    {(id: string) => (
      <>
        <path d="M18 22 C13 28 13 36 18 42" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" strokeOpacity="0.75"/>
        <path d="M46 22 C51 28 51 36 46 42" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" strokeOpacity="0.75"/>
        <path d="M23 26 C20 30 20 34 23 38" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <path d="M41 26 C44 30 44 34 41 38" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <circle cx="32" cy="32" r="7.5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="2"/>
        <circle cx="30" cy="30" r="2.2" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
