import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const AppearanceIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#EC4899"
    gradMid="#A855F7"
    gradTo="#3B0764"
    accent="#F5D0FE"
    ariaLabel="Appearance"
  >
    {(id: string) => (
      <>
        <path d="M32 15 C22 15 15 22.5 15 32 C15 41.5 22.5 48 31 48 C34.5 48 36 45.8 35.5 43.2 C35.1 41.2 36.4 39.5 38.6 39.5 H42 C46.4 39.5 49 36 49 31.5 C49 22 41.5 15 32 15 Z" fill={`url(#${id}-fg)`}/>
        <circle cx="24" cy="27" r="2.6" fill="#22D3EE"/>
        <circle cx="31" cy="22" r="2.6" fill="#FDE047"/>
        <circle cx="39" cy="25" r="2.6" fill="#F43F5E"/>
        <circle cx="23" cy="36" r="2.6" fill="#A855F7"/>
      </>
    )}
  </IconBase>
);
