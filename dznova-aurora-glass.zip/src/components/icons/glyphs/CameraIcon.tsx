import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const CameraIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#3B82F6"
    gradMid="#0EA5E9"
    gradTo="#0C4A6E"
    accent="#BAE6FD"
    ariaLabel="Camera"
  >
    {(id) => (
      <>
        <rect x="14" y="21" width="36" height="25" rx="7" fill={`url(#${id}-fg)`}/>
        <path d="M24 21 L27 16 H37 L40 21" fill="#FFFFFF" fillOpacity="0.85"/>
        <circle cx="32" cy="33.5" r="7.5" fill="#0C4A6E" stroke="#FFFFFF" strokeWidth="2.2"/>
        <circle cx="30" cy="31.5" r="2.2" fill="#67E8F9"/>
      </>
    )}
  </IconBase>
);
