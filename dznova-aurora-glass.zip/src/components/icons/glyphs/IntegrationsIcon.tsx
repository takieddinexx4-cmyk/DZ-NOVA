import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const IntegrationsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#8B5CF6"
    gradMid="#3B82F6"
    gradTo="#1E1B4B"
    accent="#C4B5FD"
    ariaLabel="Integrations"
  >
    {(id: string) => (
      <>
        <rect x="15" y="16" width="15" height="15" rx="4.5" fill={`url(#${id}-fg)`}/>
        <rect x="34" y="16" width="15" height="15" rx="4.5" fill="#FFFFFF" fillOpacity="0.55"/>
        <rect x="15" y="35" width="15" height="15" rx="4.5" fill="#FFFFFF" fillOpacity="0.55"/>
        <rect x="34" y="35" width="15" height="15" rx="4.5" fill={`url(#${id}-fg)`}/>
        <circle cx="32" cy="32" r="4.5" fill="#67E8F9" stroke="#FFFFFF" strokeWidth="1.5"/>
      </>
    )}
  </IconBase>
);
