import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const ScenesIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#6366F1"
    gradMid="#4F46E5"
    gradTo="#1E1B4B"
    accent="#C7D2FE"
    ariaLabel="Scenes"
  >
    {(id) => (
      <>
        <rect x="22" y="15" width="26" height="20" rx="5" fill="#FFFFFF" fillOpacity="0.38" stroke="#FFFFFF" strokeOpacity="0.6" strokeWidth="1.5"/>
        <rect x="18" y="22" width="26" height="20" rx="5" fill="#FFFFFF" fillOpacity="0.62"/>
        <rect x="14" y="29" width="26" height="20" rx="5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.6"/>
        <path d="M23 36 L31 39 L23 42 Z" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
