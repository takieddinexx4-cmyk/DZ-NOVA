import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const SettingsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#64748B"
    gradMid="#475569"
    gradTo="#0F172A"
    accent="#CBD5E1"
    ariaLabel="Settings"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="32" r="14" fill="#FFFFFF" fillOpacity="0.22" stroke="#FFFFFF" strokeWidth="4.5" strokeDasharray="6 4.5"/>
        <circle cx="32" cy="32" r="7" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="2"/>
      </>
    )}
  </IconBase>
);
