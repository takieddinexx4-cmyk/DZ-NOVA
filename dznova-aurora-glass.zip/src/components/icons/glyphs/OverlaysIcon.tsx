import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const OverlaysIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#06B6D4"
    gradMid="#0284C7"
    gradTo="#0C4A6E"
    accent="#A5F3FC"
    ariaLabel="Overlays"
  >
    {(id: string) => (
      <>
        <rect x="14" y="17" width="36" height="26" rx="6" fill="#FFFFFF" fillOpacity="0.22" stroke="#FFFFFF" strokeWidth="2"/>
        <rect x="18" y="21" width="12" height="7" rx="2.5" fill={`url(#${id}-fg)`}/>
        <rect x="34" y="32" width="12" height="7" rx="2.5" fill="#FFFFFF" fillOpacity="0.9"/>
        <path d="M22 48 H42" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
