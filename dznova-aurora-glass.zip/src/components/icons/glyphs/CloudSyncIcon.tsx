import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const CloudSyncIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#38BDF8"
    gradTo="#0C4A6E"
    accent="#E0F2FE"
    ariaLabel="Cloud Sync"
  >
    {(id: string) => (
      <>
        <path d="M22 42 H43 C47.5 42 50 38.8 50 35 C50 31.4 47.4 28.5 43.8 28.2 C42.6 22.5 37.6 18.5 31.8 18.5 C25.5 18.5 20.5 23.3 20.1 29.4 C16.6 30.2 14 33 14 36.4 C14 39.8 17.3 42 22 42 Z" fill={`url(#${id}-fg)`}/>
        <path d="M27 33 A5 5 0 0 1 36 30 M37 34 A5 5 0 0 1 28 37" stroke="#0C4A6E" strokeWidth="2.4" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
