import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const TtsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#14B8A6"
    gradMid="#0D9488"
    gradTo="#134E4A"
    accent="#99F6E4"
    ariaLabel="Text-to-Speech"
  >
    {(id: string) => (
      <>
        <rect x="14" y="17" width="36" height="24" rx="7" fill="#FFFFFF" fillOpacity="0.28" stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M22 29 V29 M26 24 V34 M31 21 V37 M36 25 V33 M41 27 V31" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <path d="M25 41 L21 48 L31 41" fill="#FFFFFF" fillOpacity="0.75"/>
      </>
    )}
  </IconBase>
);
