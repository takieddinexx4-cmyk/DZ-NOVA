import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const StatisticsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#10B981"
    gradTo="#064E3B"
    accent="#A7F3D0"
    ariaLabel="Statistics"
  >
    {(id: string) => (
      <>
        <path d="M32 16 A16 16 0 1 0 48 32 H32 Z" fill="#FFFFFF" fillOpacity="0.72"/>
        <path d="M35 14 A15 15 0 0 1 50 29 H35 Z" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.4"/>
      </>
    )}
  </IconBase>
);
