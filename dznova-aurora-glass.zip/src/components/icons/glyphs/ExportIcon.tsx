import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const ExportIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#10B981"
    gradMid="#0EA5E9"
    gradTo="#082F49"
    accent="#A5F3FC"
    ariaLabel="Export"
  >
    {(id) => (
      <>
        <path d="M17 37 V43 C17 45.5 19 47 22 47 H42 C45 47 47 45.5 47 43 V37" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <path d="M32 37 V17 M24 24 L32 16 L40 24" stroke={`url(#${id}-fg)`} strokeWidth="3.8" strokeLinecap="round" strokeLinejoin="round"/>
      </>
    )}
  </IconBase>
);
