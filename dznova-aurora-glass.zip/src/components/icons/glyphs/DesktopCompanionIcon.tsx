import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const DesktopCompanionIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#3B82F6"
    gradMid="#6366F1"
    gradTo="#1E1B4B"
    accent="#C7D2FE"
    ariaLabel="Desktop Companion"
  >
    {(id) => (
      <>
        <rect x="14" y="17" width="36" height="24" rx="5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M26 47 H38 M32 41 V47" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round"/>
        <rect x="20" y="23" width="12" height="8" rx="2" fill="#0F172A" fillOpacity="0.45"/>
      </>
    )}
  </IconBase>
);
