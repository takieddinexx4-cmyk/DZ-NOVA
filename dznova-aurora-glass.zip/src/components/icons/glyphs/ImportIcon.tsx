import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const ImportIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#6366F1"
    gradMid="#0EA5E9"
    gradTo="#1E1B4B"
    accent="#BAE6FD"
    ariaLabel="Import"
  >
    {(id: string) => (
      <>
        <path d="M17 37 V43 C17 45.5 19 47 22 47 H42 C45 47 47 45.5 47 43 V37" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <path d="M32 16 V36 M24 29 L32 37 L40 29" stroke={`url(#${id}-fg)`} strokeWidth="3.8" strokeLinecap="round" strokeLinejoin="round"/>
      </>
    )}
  </IconBase>
);
