import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const CountdownIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#06B6D4"
    gradMid="#3B82F6"
    gradTo="#1E1B4B"
    accent="#A5F3FC"
    ariaLabel="Countdown"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="34" r="15" fill="#FFFFFF" fillOpacity="0.22" stroke="#FFFFFF" strokeWidth="2.2"/>
        <path d="M32 19 A15 15 0 0 1 47 34" stroke="#67E8F9" strokeWidth="3.6" strokeLinecap="round"/>
        <path d="M32 34 V25 M32 34 L38 38" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round"/>
        <rect x="27" y="13" width="10" height="3.5" rx="1.75" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
