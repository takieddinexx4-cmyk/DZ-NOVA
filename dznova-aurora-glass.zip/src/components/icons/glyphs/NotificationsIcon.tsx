import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const NotificationsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#6366F1"
    gradMid="#8B5CF6"
    gradTo="#2E1065"
    accent="#DDD6FE"
    ariaLabel="Notifications"
  >
    {(id) => (
      <>
        <rect x="15" y="19" width="34" height="26" rx="7" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M17 22 L32 33 L47 22" stroke="#1E1B4B" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>
        <circle cx="46" cy="19" r="5" fill="#22D3EE" stroke="#FFFFFF" strokeWidth="1.6"/>
      </>
    )}
  </IconBase>
);
