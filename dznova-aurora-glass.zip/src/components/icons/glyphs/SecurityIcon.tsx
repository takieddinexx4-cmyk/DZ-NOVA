import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const SecurityIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#10B981"
    gradMid="#0D9488"
    gradTo="#064E3B"
    accent="#6EE7B7"
    ariaLabel="Security"
  >
    {(id) => (
      <>
        <path d="M32 14 L47 20 V32 C47 41.5 40.5 47.5 32 50.5 C23.5 47.5 17 41.5 17 32 V20 Z" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M25 32 L30 37 L40 26" stroke="#064E3B" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round"/>
      </>
    )}
  </IconBase>
);
