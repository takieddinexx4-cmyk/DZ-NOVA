import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const GoalsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#EF4444"
    gradMid="#F97316"
    gradTo="#450A0A"
    accent="#FECACA"
    ariaLabel="Stream Goals"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="32" r="16" fill="#FFFFFF" fillOpacity="0.2" stroke="#FFFFFF" strokeWidth="2.4"/>
        <circle cx="32" cy="32" r="10" fill="#FFFFFF" fillOpacity="0.3" stroke="#FFFFFF" strokeWidth="2.2"/>
        <circle cx="32" cy="32" r="4.5" fill={`url(#${id}-fg)`}/>
        <path d="M32 32 L46 18 M41 18 H46 V23" stroke="#FFFFFF" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
      </>
    )}
  </IconBase>
);
