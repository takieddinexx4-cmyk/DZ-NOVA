import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const HelpIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#8B5CF6"
    gradTo="#1E1B4B"
    accent="#DDD6FE"
    ariaLabel="Help Center"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="32" r="16" fill={`url(#${id}-fg)`} fillOpacity="0.32" stroke="#FFFFFF" strokeWidth="2.2"/>
        <path d="M27 26.5 C27 23.5 29.2 21.5 32.2 21.5 C35 21.5 37 23.2 37 25.8 C37 28 35.4 29 33.4 30 C32.3 30.6 32 31.5 32 33" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <circle cx="32" cy="39.5" r="2.2" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
