import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const LiveControlsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#2563EB"
    gradMid="#06B6D4"
    gradTo="#082F49"
    accent="#67E8F9"
    ariaLabel="Live Controls"
  >
    {(id: string) => (
      <>
        <line x1="21" y1="16" x2="21" y2="48" stroke="#FFFFFF" strokeOpacity="0.5" strokeWidth="3.2" strokeLinecap="round"/>
        <line x1="32" y1="16" x2="32" y2="48" stroke="#FFFFFF" strokeOpacity="0.5" strokeWidth="3.2" strokeLinecap="round"/>
        <line x1="43" y1="16" x2="43" y2="48" stroke="#FFFFFF" strokeOpacity="0.5" strokeWidth="3.2" strokeLinecap="round"/>
        <circle cx="21" cy="26" r="4.5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.6"/>
        <circle cx="32" cy="38" r="4.5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.6"/>
        <circle cx="43" cy="23" r="4.5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.6"/>
      </>
    )}
  </IconBase>
);
