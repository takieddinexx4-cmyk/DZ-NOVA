import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const ChatbotIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#6366F1"
    gradTo="#1E1B4B"
    accent="#7DD3FC"
    ariaLabel="AI Chatbot"
  >
    {(id) => (
      <>
        <line x1="32" y1="15" x2="32" y2="21" stroke="#FFFFFF" strokeWidth="2.8" strokeLinecap="round"/>
        <circle cx="32" cy="14" r="2.8" fill="#67E8F9"/>
        <rect x="16" y="21" width="32" height="24" rx="9" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <circle cx="26" cy="33" r="3" fill="#0F172A"/>
        <circle cx="38" cy="33" r="3" fill="#0F172A"/>
        <path d="M27 40 H37" stroke="#0F172A" strokeWidth="2.4" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
