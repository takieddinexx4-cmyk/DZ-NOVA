import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const LeaderboardsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#EAB308"
    gradMid="#CA8A04"
    gradTo="#422006"
    accent="#FEF08A"
    ariaLabel="Leaderboards"
  >
    {(id: string) => (
      <>
        <rect x="14" y="34" width="11" height="14" rx="3" fill="#FFFFFF" fillOpacity="0.6"/>
        <rect x="26.5" y="26" width="11" height="22" rx="3" fill={`url(#${id}-fg)`}/>
        <rect x="39" y="31" width="11" height="17" rx="3" fill="#FFFFFF" fillOpacity="0.78"/>
        <path d="M26 22 L28.5 16 L32 20 L35.5 16 L38 22 Z" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
