import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const MicrophoneIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#06B6D4"
    gradMid="#2563EB"
    gradTo="#172554"
    accent="#A5F3FC"
    ariaLabel="Microphone"
  >
    {(id: string) => (
      <>
        <rect x="25" y="14" width="14" height="22" rx="7" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.6"/>
        <path d="M20 31 C20 37.6 25.4 43 32 43 C38.6 43 44 37.6 44 31" stroke="#FFFFFF" strokeWidth="2.8" strokeLinecap="round"/>
        <path d="M32 43 V49 M25 49 H39" stroke="#FFFFFF" strokeWidth="2.8" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
