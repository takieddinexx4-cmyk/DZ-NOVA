import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const PerformanceIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#14B8A6"
    gradMid="#10B981"
    gradTo="#064E3B"
    accent="#99F6E4"
    ariaLabel="Performance"
  >
    {(id: string) => (
      <>
        <path d="M16 41 A17 17 0 1 1 48 41" stroke="#FFFFFF" strokeOpacity="0.4" strokeWidth="4.5" strokeLinecap="round"/>
        <path d="M16 41 A17 17 0 0 1 42 21" stroke={`url(#${id}-fg)`} strokeWidth="4.5" strokeLinecap="round"/>
        <path d="M32 38 L42 24" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <circle cx="32" cy="38" r="4" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
