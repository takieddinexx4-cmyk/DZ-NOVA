import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const WilayaBattleIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#10B981"
    gradMid="#0EA5E9"
    gradTo="#312E81"
    accent="#6EE7B7"
    ariaLabel="Wilaya Battle"
  >
    {(id: string) => (
      <>
        <path d="M32 14 L48 21 V33 C48 42 41 48 32 51 C23 48 16 42 16 33 V21 Z" fill={`url(#${id}-fg)`} fillOpacity="0.88" stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M24 25 L40 41 M40 25 L24 41" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round"/>
        <circle cx="32" cy="33" r="4.5" fill="#10B981" stroke="#FFFFFF" strokeWidth="1.8"/>
      </>
    )}
  </IconBase>
);
