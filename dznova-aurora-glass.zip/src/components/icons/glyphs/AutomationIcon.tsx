import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const AutomationIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#3B82F6"
    gradMid="#8B5CF6"
    gradTo="#1E1B4B"
    accent="#C4B5FD"
    ariaLabel="Automation"
  >
    {(id: string) => (
      <>
        <path d="M35 14 L20 34 H31 L28 50 L44 29 H33 Z" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8" strokeLinejoin="round"/>
        <circle cx="46" cy="44" r="4" fill="#67E8F9"/>
      </>
    )}
  </IconBase>
);
