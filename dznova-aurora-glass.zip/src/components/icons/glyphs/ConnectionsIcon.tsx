import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const ConnectionsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#06B6D4"
    gradMid="#0EA5E9"
    gradTo="#0C4A6E"
    accent="#67E8F9"
    ariaLabel="Connections"
  >
    {(id: string) => (
      <>
        <circle cx="20" cy="32" r="6" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <circle cx="44" cy="21" r="5.5" fill="#FFFFFF" fillOpacity="0.88"/>
        <circle cx="44" cy="43" r="5.5" fill="#FFFFFF" fillOpacity="0.88"/>
        <path d="M25.5 29.5 L39 23 M25.5 34.5 L39 41" stroke="#FFFFFF" strokeWidth="2.8" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
