import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const ChatIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#10B981"
    gradMid="#059669"
    gradTo="#064E3B"
    accent="#A7F3D0"
    ariaLabel="Live Chat"
  >
    {(id) => (
      <>
        <path d="M15 21 C15 17.5 18 15 22 15 H42 C46 15 49 17.5 49 21 V35 C49 38.5 46 41 42 41 H27 L18 48 V41 C16 40 15 38 15 35 Z" fill={`url(#${id}-fg)`}/>
        <circle cx="25" cy="28" r="2.6" fill="#064E3B"/>
        <circle cx="32" cy="28" r="2.6" fill="#064E3B"/>
        <circle cx="39" cy="28" r="2.6" fill="#064E3B"/>
      </>
    )}
  </IconBase>
);
