import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const AnalyticsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#2563EB"
    gradMid="#4F46E5"
    gradTo="#1E1B4B"
    accent="#93C5FD"
    ariaLabel="Analytics"
  >
    {(id) => (
      <>
        <rect x="16" y="34" width="7" height="14" rx="3" fill="#FFFFFF" fillOpacity="0.65"/>
        <rect x="28" y="26" width="7" height="22" rx="3" fill="#FFFFFF" fillOpacity="0.88"/>
        <rect x="40" y="18" width="7" height="30" rx="3" fill={`url(#${id}-fg)`}/>
        <path d="M16 26 L28 20 L43 14" stroke="#67E8F9" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
      </>
    )}
  </IconBase>
);
