import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const ProfileIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#38BDF8"
    gradMid="#3B82F6"
    gradTo="#1E3A8A"
    accent="#BAE6FD"
    ariaLabel="Profile"
  >
    {(id) => (
      <>
        <circle cx="32" cy="24" r="8" fill={`url(#${id}-fg)`}/>
        <path d="M17 47 C17 38.5 23.5 34 32 34 C40.5 34 47 38.5 47 47" fill="#FFFFFF" fillOpacity="0.88"/>
      </>
    )}
  </IconBase>
);
