import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const FollowersIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#8B5CF6"
    gradMid="#7C3AED"
    gradTo="#2E1065"
    accent="#DDD6FE"
    ariaLabel="Followers"
  >
    {(id) => (
      <>
        <circle cx="27" cy="24" r="7" fill="#FFFFFF" fillOpacity="0.92"/>
        <path d="M15 44 C15 36 20 33 27 33 C34 33 39 36 39 44" fill={`url(#${id}-fg)`}/>
        <circle cx="42" cy="26" r="5" fill="#FFFFFF" fillOpacity="0.6"/>
        <path d="M44 37 L46 39 L50 35" stroke="#67E8F9" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round"/>
      </>
    )}
  </IconBase>
);
