import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const PollsIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#0284C7"
    gradTo="#082F49"
    accent="#BAE6FD"
    ariaLabel="Live Polls"
  >
    {(id) => (
      <>
        <rect x="15" y="18" width="34" height="7.5" rx="3.75" fill="#FFFFFF" fillOpacity="0.35"/>
        <rect x="15" y="18" width="24" height="7.5" rx="3.75" fill={`url(#${id}-fg)`}/>
        <rect x="15" y="29" width="34" height="7.5" rx="3.75" fill="#FFFFFF" fillOpacity="0.35"/>
        <rect x="15" y="29" width="16" height="7.5" rx="3.75" fill="#FFFFFF" fillOpacity="0.9"/>
        <rect x="15" y="40" width="34" height="7.5" rx="3.75" fill="#FFFFFF" fillOpacity="0.35"/>
        <rect x="15" y="40" width="29" height="7.5" rx="3.75" fill="#67E8F9"/>
      </>
    )}
  </IconBase>
);
