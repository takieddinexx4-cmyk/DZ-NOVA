import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const LightModeIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#FBBF24"
    gradMid="#F97316"
    gradTo="#78350F"
    accent="#FEF08A"
    ariaLabel="Light Mode"
  >
    {(id: string) => (
      <>
        <circle cx="32" cy="32" r="9.5" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.8"/>
        <path d="M32 14 V18 M32 46 V50 M14 32 H18 M46 32 H50 M19.3 19.3 L22.2 22.2 M41.8 41.8 L44.7 44.7 M44.7 19.3 L41.8 22.2 M22.2 41.8 L19.3 44.7" stroke="#FFFFFF" strokeWidth="2.8" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
