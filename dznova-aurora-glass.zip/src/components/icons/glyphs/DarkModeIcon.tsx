import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const DarkModeIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#6366F1"
    gradMid="#312E81"
    gradTo="#0F172A"
    accent="#C7D2FE"
    ariaLabel="Dark Mode"
  >
    {(id: string) => (
      <>
        <path d="M39 39 A13.5 13.5 0 1 1 26 19 A10.5 10.5 0 0 0 39 39 Z" fill={`url(#${id}-fg)`} stroke="#FFFFFF" strokeWidth="1.6"/>
        <circle cx="43" cy="21" r="2.2" fill="#67E8F9"/>
        <circle cx="47" cy="28" r="1.4" fill="#FFFFFF"/>
      </>
    )}
  </IconBase>
);
