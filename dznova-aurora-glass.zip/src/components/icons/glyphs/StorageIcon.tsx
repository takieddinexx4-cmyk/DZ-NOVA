import React from 'react';
import { IconBase, AuroraIconProps } from '../IconBase';

export const StorageIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#4F46E5"
    gradMid="#3730A3"
    gradTo="#1E1B4B"
    accent="#A5B4FC"
    ariaLabel="Storage"
  >
    {(id: string) => (
      <>
        <ellipse cx="32" cy="21" rx="15" ry="5.5" fill={`url(#${id}-fg)`}/>
        <path d="M17 21 V32 C17 35 23.7 37.5 32 37.5 C40.3 37.5 47 35 47 32 V21" fill="#FFFFFF" fillOpacity="0.32" stroke="#FFFFFF" strokeWidth="1.6"/>
        <path d="M17 32 V43 C17 46 23.7 48.5 32 48.5 C40.3 48.5 47 46 47 43 V32" fill="#FFFFFF" fillOpacity="0.2" stroke="#FFFFFF" strokeWidth="1.6"/>
        <circle cx="40" cy="40" r="2" fill="#67E8F9"/>
      </>
    )}
  </IconBase>
);
