import React from 'react';
import { IconBase, AuroraIconProps } from './IconBase';

export const AccountManagementIcon: React.FC<AuroraIconProps> = (props) => (
  <IconBase
    {...props}
    gradFrom="#0EA5E9"
    gradMid="#4F46E5"
    gradTo="#1E1B4B"
    accent="#BAE6FD"
    ariaLabel="Account Management"
  >
    {(id) => (
      <>
        <rect x="14" y="19" width="36" height="26" rx="6" fill="#FFFFFF" fillOpacity="0.24" stroke="#FFFFFF" strokeWidth="1.8"/>
        <circle cx="24" cy="30" r="4.2" fill={`url(#${id}-fg)`}/>
        <path d="M18.5 40 C18.5 36.8 21 35.5 24 35.5 C27 35.5 29.5 36.8 29.5 40" fill="#FFFFFF"/>
        <path d="M34 28 H44 M34 34 H41" stroke="#FFFFFF" strokeWidth="2.4" strokeLinecap="round"/>
      </>
    )}
  </IconBase>
);
