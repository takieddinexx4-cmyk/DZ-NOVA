export const AURORA_SPRING = {
  type: 'spring' as const,
  stiffness: 320,
  damping: 28,
  mass: 0.85,
};

export const AURORA_EASE = [0.22, 1, 0.36, 1] as const;

export const PAGE_TRANSITION = {
  initial: { opacity: 0, y: 12, scale: 0.99 },
  animate: { opacity: 1, y: 0, scale: 1 },
  exit: { opacity: 0, y: -8, scale: 0.99 },
  transition: { duration: 0.28, ease: AURORA_EASE },
};

export function runWithViewTransition(updateFn: () => void, reducedMotion: boolean) {
  const doc = document as Document & { startViewTransition?: (cb: () => void) => void };
  if (!reducedMotion && typeof doc.startViewTransition === 'function') {
    doc.startViewTransition(updateFn);
  } else {
    updateFn();
  }
}
