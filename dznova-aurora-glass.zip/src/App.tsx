import React, { Suspense, lazy, useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DznovaLogo, LogoVariant } from './components/brand/DznovaLogo';
import { DznovaLogoIntro } from './components/brand/DznovaLogoIntro';
import { AuroraAtmosphere } from './components/atmosphere/AuroraAtmosphere';
import { GlassCard, GlassModal, GlassToggle, AnimatedCounter } from './components/glass/GlassPrimitives';
import {
  DZNOVA_ICON_REGISTRY,
  IconSize,
  DashboardIcon,
  LiveStreamingIcon,
  ObsIcon,
  OverlaysIcon,
  GiftsIcon,
  FollowersIcon,
  WilayaBattleIcon,
  AppearanceIcon,
  SearchIcon,
  NotificationsIcon,
  LightModeIcon,
  DarkModeIcon,
  LanguageIcon,
  PerformanceIcon,
  AlertsIcon,
  LiveControlsIcon,
} from './components/icons';
import { TRANSLATIONS, Lang } from './i18n/translations';
import { PAGE_TRANSITION, runWithViewTransition } from './motion/config';

const DashboardHero3D = lazy(() => import('./components/atmosphere/DashboardHero3D'));

type PageId = 'dashboard' | 'icons' | 'brand' | 'overlays' | 'uikit';

interface StreamEvent {
  id: string;
  type: 'gift' | 'follow' | 'battle';
  user: string;
  detail: string;
  time: string;
}

export function App() {
  const [lang, setLang] = useState<Lang>('ar');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [lowPerf, setLowPerf] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [showIntro, setShowIntro] = useState(false);
  const [page, setPage] = useState<PageId>('dashboard');
  const [isLive, setIsLive] = useState(true);
  const [search, setSearch] = useState('');
  const [iconCat, setIconCat] = useState('All');
  const [iconSize, setIconSize] = useState<IconSize>('lg');
  const [selectedIconId, setSelectedIconId] = useState('dashboard');
  const [notifOpen, setNotifOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  const [stats, setStats] = useState({
    viewers: 1428,
    gifts: 28450,
    followers: 312,
    wilaya: 18940,
  });

  const [overlays, setOverlays] = useState([
    { id: 'wilaya', name: 'Wilaya Battle HUD', nameAr: 'لوحة تحدي الولايات', active: true },
    { id: 'gifts', name: 'Crystal Gift Rain', nameAr: 'مطر الهدايا الكريستالي', active: true },
    { id: 'alerts', name: 'Aurora Alert Box', nameAr: 'صندوق التنبيهات الزجاجي', active: true },
    { id: 'chat', name: 'Frosted Chat Dock', nameAr: 'شريط الدردشة الضبابي', active: false },
    { id: 'goal', name: 'Diamond Goal Bar', nameAr: 'شريط هدف الماسات', active: true },
  ]);

  const [events, setEvents] = useState<StreamEvent[]>([
    { id: 'e1', type: 'battle', user: 'Wilaya 18 — Jijel', detail: '+2,400 Nova Boost', time: '00:12' },
    { id: 'e2', type: 'gift', user: 'Amine_DZ', detail: 'Aurora Crown (500)', time: '01:04' },
    { id: 'e3', type: 'follow', user: 'Yasmine.Live', detail: 'Joined DZNOVA Squad', time: '02:19' },
  ]);

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', lang);
    document.documentElement.setAttribute('data-perf', lowPerf ? 'low' : 'high');
    document.documentElement.setAttribute('data-reduced-motion', String(reducedMotion));
  }, [theme, lang, lowPerf, reducedMotion]);

  const switchPage = (next: PageId) => {
    runWithViewTransition(() => setPage(next), reducedMotion);
  };

  const simulateEvent = (type: 'gift' | 'follow' | 'battle') => {
    const now = new Date();
    const stamp = `${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    if (type === 'gift') {
      setStats((s) => ({ ...s, gifts: s.gifts + 500, viewers: s.viewers + 12 }));
      setEvents((ev) => [{ id: String(Date.now()), type, user: 'Karim_Pro', detail: 'Crystal Nova (500)', time: stamp }, ...ev.slice(0, 6)]);
    } else if (type === 'follow') {
      setStats((s) => ({ ...s, followers: s.followers + 1, viewers: s.viewers + 3 }));
      setEvents((ev) => [{ id: String(Date.now()), type, user: 'Nour_Stream', detail: 'New Follower', time: stamp }, ...ev.slice(0, 6)]);
    } else {
      setStats((s) => ({ ...s, wilaya: s.wilaya + 1250 }));
      setEvents((ev) => [{ id: String(Date.now()), type, user: 'Wilaya 16 — Algiers', detail: '+1,250 Surge', time: stamp }, ...ev.slice(0, 6)]);
    }
  };

  const categories = useMemo(
    () => ['All', ...Array.from(new Set(DZNOVA_ICON_REGISTRY.map((i) => i.category)))],
    []
  );

  const filteredIcons = useMemo(
    () =>
      DZNOVA_ICON_REGISTRY.filter((i) => {
        const matchCat = iconCat === 'All' || i.category === iconCat;
        const q = search.trim().toLowerCase();
        const matchQ = !q || i.name.toLowerCase().includes(q) || i.nameAr.includes(q) || i.id.includes(q);
        return matchCat && matchQ;
      }),
    [iconCat, search]
  );

  const navItems: { id: PageId; label: string; Icon: React.FC<any> }[] = [
    { id: 'dashboard', label: t.nav.dashboard, Icon: DashboardIcon },
    { id: 'icons', label: t.nav.icons, Icon: AppearanceIcon },
    { id: 'brand', label: t.nav.brand, Icon: LiveStreamingIcon },
    { id: 'overlays', label: t.nav.overlays, Icon: OverlaysIcon },
    { id: 'uikit', label: t.nav.uikit, Icon: LiveControlsIcon },
  ];

  const activeOverlayCount = overlays.filter((o) => o.active).length;

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      <AuroraAtmosphere lowPerf={lowPerf} theme={theme} />
      <DznovaLogoIntro visible={showIntro} reducedMotion={reducedMotion} onComplete={() => setShowIntro(false)} />

      {/* Frosted Glass Sidebar */}
      <aside className="aurora-glass aurora-glass-strong lg:w-72 shrink-0 m-3 lg:m-4 rounded-3xl p-4 flex flex-col gap-5">
        <div className="flex items-center justify-between">
          <DznovaLogo variant={theme === 'light' ? 'light' : 'compact'} size={42} />
        </div>

        <nav className="flex lg:flex-col gap-2 overflow-x-auto pb-1 lg:pb-0">
          {navItems.map(({ id, label, Icon }) => {
            const active = page === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => switchPage(id)}
                className={`flex items-center gap-3 px-3.5 py-2.5 rounded-2xl text-sm font-semibold transition-all shrink-0 ${
                  active
                    ? 'bg-gradient-to-r from-cyan-400/20 via-blue-500/20 to-violet-500/20 border border-cyan-300/40 shadow-lg'
                    : 'hover:bg-white/10 border border-transparent'
                }`}
              >
                <Icon size="sm" selected={active} interactive={false} />
                <span>{label}</span>
              </button>
            );
          })}
        </nav>

        <div className="mt-auto hidden lg:flex flex-col gap-2 pt-3 border-t border-white/10">
          <GlassToggle checked={lowPerf} onChange={setLowPerf} label={t.lowPerf} />
          <GlassToggle checked={reducedMotion} onChange={setReducedMotion} label={t.reducedMotion} />
        </div>
      </aside>

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0 p-3 lg:p-4 lg:ps-0 gap-4">
        {/* Liquid Glass Top Navigation Bar */}
        <header className="aurora-glass rounded-3xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 flex-1 min-w-[200px] max-w-md aurora-glass rounded-2xl px-3 py-1.5">
            <SearchIcon size="xs" interactive={false} />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setLang((l) => (l === 'ar' ? 'en' : 'ar'))}
              className="crystal-btn aurora-glass px-3 py-2 text-xs"
            >
              <LanguageIcon size="xs" interactive={false} />
              <span>{lang === 'ar' ? 'EN' : 'العربية'}</span>
            </button>
            <button
              type="button"
              onClick={() => setTheme((th) => (th === 'dark' ? 'light' : 'dark'))}
              className="crystal-btn aurora-glass px-3 py-2 text-xs"
            >
              {theme === 'dark' ? <LightModeIcon size="xs" interactive={false} /> : <DarkModeIcon size="xs" interactive={false} />}
            </button>
            <button
              type="button"
              onClick={() => setNotifOpen((o) => !o)}
              className="crystal-btn aurora-glass px-3 py-2 text-xs"
            >
              <NotificationsIcon size="xs" interactive={false} />
              <span className="tabular-nums">{events.length}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsLive((v) => !v)}
              className={`crystal-btn px-4 py-2 text-xs ${isLive ? 'bg-rose-500/90 text-white shadow-lg' : 'crystal-btn-primary'}`}
            >
              <LiveStreamingIcon size="xs" interactive={false} />
              <span>{isLive ? t.endStream : t.goLive}</span>
            </button>
          </div>
        </header>

        {/* Floating Notification Drawer */}
        <AnimatePresence>
          {notifOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="aurora-glass aurora-glass-strong rounded-3xl p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-bold text-sm">{t.notifications}</span>
                <button type="button" onClick={() => setEvents([])} className="text-xs text-cyan-400 hover:underline">
                  {t.clearAll}
                </button>
              </div>
              <div className="grid sm:grid-cols-3 gap-2">
                {events.slice(0, 3).map((ev) => (
                  <div key={ev.id} className="rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-xs">
                    <div className="font-semibold">{ev.user}</div>
                    <div className="opacity-75">{ev.detail}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Active Page */}
        <AnimatePresence mode="wait">
          <motion.main key={page} {...PAGE_TRANSITION} className="flex-1 flex flex-col gap-4">
            {page === 'dashboard' && (
              <>
                {/* Welcome Hero + Dynamically Loaded R3F Crystal */}
                <GlassCard className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-2">
                    <div className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold bg-cyan-400/15 border border-cyan-300/30 text-cyan-300">
                      <span className={`h-2 w-2 rounded-full ${isLive ? 'bg-rose-500 animate-pulse' : 'bg-emerald-400'}`} />
                      <span>{isLive ? t.live : t.offline}</span>
                    </div>
                    <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">{t.welcomeTitle}</h1>
                    <p className="text-sm opacity-75">{t.welcomeSub}</p>
                    <div className="flex flex-wrap gap-2 pt-2">
                      <button type="button" onClick={() => simulateEvent('gift')} className="crystal-btn crystal-btn-primary px-4 py-2 text-xs">
                        <GiftsIcon size="xs" interactive={false} /> {t.simulateGift}
                      </button>
                      <button type="button" onClick={() => simulateEvent('battle')} className="crystal-btn aurora-glass px-4 py-2 text-xs">
                        <WilayaBattleIcon size="xs" interactive={false} /> {t.simulateBattle}
                      </button>
                      <button type="button" onClick={() => setShowIntro(true)} className="crystal-btn aurora-glass px-4 py-2 text-xs">
                        {t.replayIntro}
                      </button>
                    </div>
                  </div>
                  {!lowPerf && !reducedMotion && (
                    <Suspense fallback={<div className="h-36 w-36 rounded-3xl aurora-glass" />}>
                      <DashboardHero3D />
                    </Suspense>
                  )}
                </GlassCard>

                {/* Floating Stat Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
                  {[
                    { label: t.stats.viewers, value: stats.viewers, Icon: LiveStreamingIcon },
                    { label: t.stats.gifts, value: stats.gifts, Icon: GiftsIcon },
                    { label: t.stats.followers, value: stats.followers, Icon: FollowersIcon },
                    { label: t.stats.wilaya, value: stats.wilaya, Icon: WilayaBattleIcon },
                  ].map((card) => (
                    <GlassCard key={card.label} className="flex items-center justify-between">
                      <div>
                        <div className="text-xs opacity-70 mb-1">{card.label}</div>
                        <div className="text-2xl font-extrabold">
                          <AnimatedCounter value={card.value} />
                        </div>
                      </div>
                      <card.Icon size="lg" idleFloat />
                    </GlassCard>
                  ))}
                </div>

                {/* Stream Health + Recent Events + Active Overlays */}
                <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
                  <GlassCard className="xl:col-span-2 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <PerformanceIcon size="sm" interactive={false} />
                        <h2 className="font-bold">{t.streamHealth}</h2>
                      </div>
                      <span className="text-xs tabular-nums text-emerald-400 font-semibold">60 FPS · 6,200 kbps · 0% Drop</span>
                    </div>
                    <div className="grid grid-cols-12 items-end gap-2 h-36 pt-4">
                      {[62, 68, 74, 71, 82, 88, 85, 92, 96, 91, 95, 98].map((v, idx) => (
                        <div key={idx} className="flex flex-col items-center gap-1 h-full justify-end">
                          <div
                            className="w-full rounded-t-xl bg-gradient-to-t from-blue-600/80 via-cyan-400/90 to-violet-300"
                            style={{ height: `${v}%` }}
                          />
                        </div>
                      ))}
                    </div>
                  </GlassCard>

                  <GlassCard className="space-y-3">
                    <div className="flex items-center gap-2.5">
                      <AlertsIcon size="sm" interactive={false} />
                      <h2 className="font-bold">{t.recentEvents}</h2>
                    </div>
                    <div className="space-y-2">
                      {events.map((ev) => (
                        <div key={ev.id} className="flex items-center justify-between rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-xs">
                          <div>
                            <div className="font-semibold">{ev.user}</div>
                            <div className="opacity-70">{ev.detail}</div>
                          </div>
                          <span className="tabular-nums opacity-60">{ev.time}</span>
                        </div>
                      ))}
                    </div>
                  </GlassCard>
                </div>
              </>
            )}

            {page === 'icons' && (
              <GlassCard className="space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h2 className="text-xl font-bold">{t.nav.icons} ({filteredIcons.length}/50)</h2>
                    <p className="text-xs opacity-75">ColorOS-inspired 3D liquid glass SVG components — hover for 3D tilt, click for pulse & selection glow.</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(['sm', 'md', 'lg', 'xl'] as IconSize[]).map((sz) => (
                      <button
                        key={String(sz)}
                        type="button"
                        onClick={() => setIconSize(sz)}
                        className={`crystal-btn px-3 py-1.5 text-xs ${iconSize === sz ? 'crystal-btn-primary' : 'aurora-glass'}`}
                      >
                        {String(sz).toUpperCase()}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setIconCat(cat)}
                      className={`px-3 py-1 rounded-full text-xs font-semibold border transition ${
                        iconCat === cat ? 'bg-cyan-400/25 border-cyan-300/60' : 'border-white/15 hover:bg-white/10'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 xl:grid-cols-6 gap-3">
                  {filteredIcons.map(({ id, name, nameAr, component: IconComp }) => (
                    <div
                      key={id}
                      onClick={() => setSelectedIconId(id)}
                      className={`rounded-2xl p-3 flex flex-col items-center gap-2.5 border transition cursor-pointer ${
                        selectedIconId === id
                          ? 'bg-cyan-400/15 border-cyan-300/50'
                          : 'bg-white/5 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      <IconComp size={iconSize} selected={selectedIconId === id} />
                      <div className="text-center">
                        <div className="text-xs font-semibold">{lang === 'ar' ? nameAr : name}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            )}

            {page === 'brand' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(['horizontal', 'icon', 'compact', 'dark', 'light', 'mono-light', 'mono-dark'] as LogoVariant[]).map((v) => (
                  <GlassCard
                    key={v}
                    className={`flex flex-col items-center justify-center gap-4 min-h-[170px] ${
                      v === 'light' || v === 'mono-dark' ? '!bg-sky-50/90 !text-slate-900' : ''
                    }`}
                  >
                    <DznovaLogo variant={v} size={64} />
                    <span className="text-xs font-semibold uppercase tracking-widest opacity-70">{v}</span>
                  </GlassCard>
                ))}
              </div>
            )}

            {page === 'overlays' && (
              <GlassCard className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <ObsIcon size="md" interactive={false} />
                    <div>
                      <h2 className="text-lg font-bold">{t.activeOverlays}</h2>
                      <p className="text-xs opacity-75 tabular-nums">{activeOverlayCount} / {overlays.length}</p>
                    </div>
                  </div>
                </div>
                {activeOverlayCount === 0 && (
                  <div className="rounded-2xl border border-dashed border-cyan-300/40 p-6 text-center space-y-1">
                    <div className="font-bold">{t.emptyOverlaysTitle}</div>
                    <p className="text-xs opacity-75">{t.emptyOverlaysDesc}</p>
                  </div>
                )}
                <div className="grid sm:grid-cols-2 gap-3">
                  {overlays.map((ov) => (
                    <div key={ov.id} className="rounded-2xl bg-white/5 border border-white/10 px-4 py-3">
                      <GlassToggle
                        checked={ov.active}
                        label={lang === 'ar' ? ov.nameAr : ov.name}
                        onChange={(next) =>
                          setOverlays((list) => list.map((item) => (item.id === ov.id ? { ...item, active: next } : item)))
                        }
                      />
                    </div>
                  ))}
                </div>
              </GlassCard>
            )}

            {page === 'uikit' && (
              <GlassCard className="space-y-4">
                <h2 className="text-xl font-bold">{t.nav.uikit}</h2>
                <div className="flex flex-wrap gap-3">
                  <button type="button" onClick={() => setModalOpen(true)} className="crystal-btn crystal-btn-primary px-5 py-2.5 text-sm">
                    Open Glass Modal
                  </button>
                  <button type="button" onClick={() => setShowIntro(true)} className="crystal-btn aurora-glass px-5 py-2.5 text-sm">
                    {t.replayIntro}
                  </button>
                </div>
              </GlassCard>
            )}
          </motion.main>
        </AnimatePresence>
      </div>

      <GlassModal open={modalOpen} title="DZNOVA Aurora Glass Modal" onClose={() => setModalOpen(false)}>
        <p className="text-sm opacity-85 mb-4">
          Translucent crystal surface with layered specular highlights, smooth spring entrance, and automatic reduced-motion fallback.
        </p>
        <button type="button" onClick={() => setModalOpen(false)} className="crystal-btn crystal-btn-primary px-4 py-2 text-xs">
          Confirm
        </button>
      </GlassModal>
    </div>
  );
}

export default App;
